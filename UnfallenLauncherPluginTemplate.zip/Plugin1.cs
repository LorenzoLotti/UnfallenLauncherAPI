﻿using System;
using System.Collections.Generic;
$if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$using System.Text;
using System.Drawing;
using UnfallenLauncherAPI;
using UnfallenLauncherAPI.Default;

namespace $safeprojectname$
{
    public class Plugin1: IPlugin
    {
        public IHost Host => new Host();
        public bool VisibleInMenu => true;
        public uint Version => 1;
        public string Developer => "Developer";
        public string Name => "Plugin";
        public Image Icon => null;

        public void OnPluginMenuItemClick()
        {
            //TODO: Handle the event.
        }
    }

    public class Host: CompleteHostBase
    {
        protected override void OnStart()
        {
            //TODO: Handle the event.
        }
    }
}
